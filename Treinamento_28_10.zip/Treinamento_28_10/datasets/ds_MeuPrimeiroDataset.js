function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var dataset = DatasetBuilder.newDataset ();
	
	//Criar Colunas
	dataset.addColumn("Sigla");
	dataset.addColumn("Estado");
	dataset.addColumn("Capital");
	dataset.addColumn("Area");
	
	//Cria Registros
	dataset.addRow(new Array("AM", "Amazonas", "Manaus", 183282));
	dataset.addRow(new Array("PA", "Para", "Belém", 989080));
	dataset.addRow(new Array("MT", "Mato Grosso", "Cuiába", 74894));
	dataset.addRow(new Array("TO", "Tocantins", "Palmas", 8749877));
	dataset.addRow(new Array("PI", "Piauí", "Teresina", 873249779));
	
	return dataset;
	

}function onMobileSync(user) {

}
function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var dataset = DatasetBuilder.newDataset ();
	
	dataset.addColumn("Moeda");
	dataset.addColumn("Simbolo");
	
	dataset.addRow(new Array("Real", "$"));
	dataset.addRow(new Array("Dolar", "U$$"));
	dataset.addRow(new Array("Pesos", "P"));
	
	return dataset;

}function onMobileSync(user) {

}
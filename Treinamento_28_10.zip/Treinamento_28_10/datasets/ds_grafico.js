function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	

	var dataset = DatasetBuilder.newDataset ();
	
	//Criar Colunas
	dataset.addColumn("Produto");
	dataset.addColumn("Valor");
	dataset.addColumn("Valor1");
		
	//Cria Registros
	dataset.addRow(new Array("Fluig",10000, 300));
	dataset.addRow(new Array("Protheus", 50000, 100));
	dataset.addRow(new Array("RM", 40000, 900));
	dataset.addRow(new Array("Datasul", 80000, 800));
	dataset.addRow(new Array("Logix", 30000, 650));
	dataset.addRow(new Array("MV", 70000, 400));
	dataset.addRow(new Array("Portinari", 20000, 200));
	
	return dataset;
	

}function onMobileSync(user) {

}
function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var c1 = DatasetFactory.createConstraint ("ccod","09013901","09013901", ConstraintType.MUST);
	var c2 = DatasetFactory.createConstraint ("cdescr","Victoria","Victoria", ConstraintType.MUST);
	var c3 = DatasetFactory.createConstraint ("ctipo","PA","PA", ConstraintType.MUST);
	var params = new Array (c1, c2, c3);
	var dataset = DatasetFactory.getDataset ("ds_baseProtheus", null, params, null);
	
	return dataset;
	

}function onMobileSync(user) {

}
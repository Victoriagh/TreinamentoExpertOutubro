var MyWidget = SuperWidget.extend({
    //variáveis da widget
    variavelNumerica: null,
    variavelCaracter: null,

    //método iniciado quando a widget é carregada
    init: function() {
    	
    	var _this = this;
        var _Jsonret = null; 
        
        $.ajax({
        	async: false,
        	type: "GET",
        	dataType: "json",
        	url: '/api/public/ecm/document/listDocument/0',
        	success: function(retorno){
        		_Jsonret = retorno;
        		
        		$.each(_Jsonret.content, function(k,v){
        			$("#documentos_diretorios_" +_this.instanceId).append("<option value="+ v.id +">"+v.description + "</option>");
        		});
        		
        	}
        	
        });
    },
  
    //BIND de eventos
    bindings:
    {
        local: {
            'carregaDiretorio': ['change_fnCarrega']
        }
    },

    
    fnCarrega: function(){
    	var _this = this;
    	var iddiretorio = $("#documentos_diretorios_"+ _this.instanceId).val();
    	
    	var _Jsonret = null; 
    	
    	$.ajax({
        	async: false,
        	type: "GET",
        	dataType: "json",
        	url: '/api/public/ecm/document/listDocument/'+ iddiretorio,
        	success: function(retorno){
        		_Jsonret = retorno;
        	
        	$(".diretorios").remove();	
        		
        	var registros = _Jsonret.content.length; 
        	$("#bagde_diretorios_" +_this.instanceId).text(registros);
        	
        	$.each(_Jsonret.content, function(k,v){
    			$("#listar_diretorios_" +_this.instanceId).append('<li class="list-group-item diretorios">' + v.description +'</li>');
        		});
    		
        	}
		});
	}
})
        	
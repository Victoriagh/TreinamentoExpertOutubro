function servicetask7(attempt, message) {
	
	
	var ccod = hAPI.getCardValue ("ccod");
	var cdescr = hAPI.getCardValue ("cdescr");
	var ctipo = hAPI.getCardValue ("ctipo");
	
	var c1 = DatasetFactory.createConstraint ("ccod",ccod, ccod, ConstraintType.MUST);
	var c2 = DatasetFactory.createConstraint ("cdescr",cdescr,cdescr, ConstraintType.MUST);
	var c3 = DatasetFactory.createConstraint ("ctipo",ctipo, ctipo, ConstraintType.MUST);
	var params = new Array (c1, c2, c3);
	var dataset = DatasetFactory.getDataset ("ds_baseProtheus", null, params, null);
	
	
	
}